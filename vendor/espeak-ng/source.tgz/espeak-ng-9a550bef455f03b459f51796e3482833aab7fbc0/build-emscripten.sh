rm -r -f build-native
rm -r -f build-emscripten

cmake -B build-native \
  -D CMAKE_BUILD_TYPE=Release \
  -D CMAKE_INSTALL_PREFIX=/usr \
  -D USE_ASYNC=OFF \
  -D USE_MBROLA=OFF \
  -D USE_LIBPCAUDIO=OFF \
  -D USE_LIBSONIC=OFF \
  -D ENABLE_TESTS=OFF

cmake --build build-native -j 4
cmake --build build-native --target data

emcmake cmake -B build-emscripten \
  -D CMAKE_BUILD_TYPE=Release \
  -D CMAKE_C_FLAGS_RELEASE="-O3 -DNDEBUG -flto=thin" \
  -D CMAKE_CXX_FLAGS_RELEASE="-O3 -DNDEBUG -flto=thin" \
  -D CMAKE_INSTALL_PREFIX=/usr \
  -D BUILD_SHARED_LIBS=OFF \
  -D USE_ASYNC=OFF \
  -D USE_MBROLA=OFF \
  -D USE_LIBPCAUDIO=OFF \
  -D USE_LIBSONIC=OFF \
  -D USE_SPEECHPLAYER=ON \
  -D USE_KLATT=ON \
  -D COMPILE_INTONATIONS=OFF \
  -D ENABLE_TESTS=OFF

cmake --build build-emscripten -j 4

cd emscripten
emmake make clean
emmake make
cd ..
